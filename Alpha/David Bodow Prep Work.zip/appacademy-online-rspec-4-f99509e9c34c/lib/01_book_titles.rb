class Book
  # TODO: your code goes here!
  attr_reader :title

# A note to the grader:
# This assignment originally has "def title(str)"
# instead of "def title=(str)"
# Please fix!!!!! This was very confusing!

  def title=(str)
    articles = %w[a an the]
    coordinating = %w[for and nor but or yet so] #FANBOYS
    prepositions = %w[of in to for with on at from by about as into like through after over between out against during without before under around among]

    out = str.split(" ").each do |word|
      word.capitalize! unless (coordinating + prepositions + articles).include?(word)
    end
    out[0].capitalize!
    @title = out.join(" ")
  end
end
