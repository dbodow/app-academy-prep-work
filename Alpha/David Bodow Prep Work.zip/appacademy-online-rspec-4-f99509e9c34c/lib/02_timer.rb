class Timer
  attr_accessor :seconds, :time_string

  def initialize
    @seconds = 0
  end

  def seconds=(int)
    @seconds = int
  end

  def time_string
    sec = padded(@seconds % 60)
    min = padded(@seconds / 60 % 60)
    hrs = padded(@seconds / 60**2 % 60)
    @time_string = hrs + ":" + min + ":" + sec
  end

  def padded(int)
    if int - 10 < 0
      "0" + int.to_s
    else
      int.to_s
    end
  end
end
