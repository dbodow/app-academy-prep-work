class Dictionary
  # TODO: your code goes here!
  attr_reader :entries

  def initialize
    @entries = {}
    @keywords = []
  end

  def keywords
    @keywords.sort
  end

  def add(entry)
    if entry.is_a?(String)
      @entries[entry] = nil
      @keywords |= [entry]
    elsif entry.is_a?(Hash)
      @entries.merge!(entry)
      @keywords |= entry.keys
    end
    nil
  end

  def include?(word)
    !!@keywords.include?(word)
  end

  def find(word)
    matches = @keywords.select { |item| is_substring?(item, word) }
    @entries.select { |key, val| matches.include?(key) }
  end

  def printable
    out = ""
    keywords.each do |word|
      heading = '[' + word.to_s + ']'
      body = '"' + @entries[word] + '"'
      out += heading + ' ' + body + "\n"
    end
    out[0...-1]
  end
end

# Helper function; public b/c it's broadly useful
def is_substring?(str,sub)
  len = sub.length
  str.chars.each_with_index do |ch, i|
    return true if str[i...i+len] == sub
  end
  false
end
