class Friend
  # TODO: your code goes here!
  def greeting(person = nil)
    case person
    when nil
      "Hello!"
    else
      "Hello, #{person}!"
    end
  end
end
