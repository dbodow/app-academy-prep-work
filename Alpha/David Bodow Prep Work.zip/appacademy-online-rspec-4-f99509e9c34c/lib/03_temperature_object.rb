class Temperature
  # TODO: your code goes here!
  attr_reader :in_fahrenheit, :in_celsius

  def initialize(hsh)
    if hsh.has_key?(:f)
      @in_fahrenheit = hsh[:f]
      @in_celsius = ftoc(hsh[:f])
    elsif hsh.has_key?(:c)
      @in_celsius = hsh[:c]
      @in_fahrenheit = ctof(hsh[:c])
    end
  end

  def self.from_celsius(deg_c)
    Temperature.new(:c => deg_c)
  end

  def self.from_fahrenheit(deg_f)
    Temperature.new(:f => deg_f)
  end

  def ftoc(fahrenheit)
    (fahrenheit - 32) * 5 / 9.0
  end

  def ctof(celsius)
    celsius * 9 / 5.0 + 32
  end

end

class Celsius < Temperature

  def initialize(int)
    @in_celsius = int
    @in_fahrenheit = ctof(int)
  end

end

class Fahrenheit < Temperature

  def initialize(int)
    @in_fahrenheit = int
    @in_celsius = ftoc(int)
  end

end
