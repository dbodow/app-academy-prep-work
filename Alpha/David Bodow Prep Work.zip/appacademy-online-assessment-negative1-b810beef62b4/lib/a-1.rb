# Given an array of unique integers ordered from least to greatest, write a
# method that returns an array of the integers that are needed to
# fill in the consecutive set.

def missing_numbers(nums)
  smallest = nums[0]
  biggest = nums[-1]
  missing = []
  (smallest..biggest).each{ |i| missing << i if nums.none?{|x| x == i}}
  missing
end

# Write a method that given a string representation of a binary number will
# return that binary number in base 10.
#
# To convert from binary to base 10, we take the sum of each digit multiplied by
# two raised to the power of its index. For example:
#   1001 = [ 1 * 2^3 ] + [ 0 * 2^2 ] + [ 0 * 2^1 ] + [ 1 * 2^0 ] = 9
#
# You may NOT use the Ruby String class's built in base conversion method.

def base2to10(binary)
  return nil if binary == nil
  sum = 0
  binary.chars.reverse.each_with_index { |n, i| sum += (2**i) if n != "0" }
  sum
end

class Hash

  # Hash#select passes each key-value pair of a hash to the block (the proc
  # accepts two arguments: a key and a value). Key-value pairs that return true
  # when passed to the block are added to a new hash. Key-value pairs that return
  # false are not. Hash#select then returns the new hash.
  #
  # Write your own Hash#select method by monkey patching the Hash class. Your
  # Hash#my_select method should have the functionailty of Hash#select described
  # above. Do not use Hash#select in your method.

  def my_select(&prc)
    out = {}
    self.each { |key, val| out[key] = val if prc.call(key,val) }
    out
  end

end

class Hash

  # Hash#merge takes a proc that accepts three arguments: a key and the two
  # corresponding values in the hashes being merged. Hash#merge then sets that
  # key to the return value of the proc in a new hash. If no proc is given,
  # Hash#merge simply merges the two hashes.
  #
  # Write a method with the functionality of Hash#merge. Your Hash#my_merge method
  # should optionally take a proc as an argument and return a new hash. If a proc
  # is not given, your method should provide default merging behavior. Do not use
  # Hash#merge in your method.

  def my_merge(new_hash, &prc) # prc takes key, old_val, and new_val
    prc = Proc.new { |key, val_o, val_n| val_n } if prc.nil? # Default proc behavior
    self.each do |key, val| # update hash at collisions
        self[key] = prc.call(key,val,new_hash[key]) unless !new_hash.key?(key)
    end
    # add missing pairs in
    new_hash.reject!{ |key, val| self.key?(key) }
    new_hash.each { |key, val| self[key] = val }
    self
  end
end

# The Lucas series is a sequence of integers that extends infinitely in both
# positive and negative directions.
#
# The first two numbers in the Lucas series are 2 and 1. A Lucas number can
# be calculated as the sum of the previous two numbers in the sequence.
# A Lucas number can also be calculated as the difference between the next
# two numbers in the sequence.
#
# All numbers in the Lucas series are indexed. The number 2 is
# located at index 0. The number 1 is located at index 1, and the number -1 is
# located at index -1. You might find the chart below helpful:
#
# Lucas series: ...-11,  7,  -4,  3,  -1,  2,  1,  3,  4,  7,  11...
# Indices:      ... -5, -4,  -3, -2,  -1,  0,  1,  2,  3,  4,  5...
#
# Write a method that takes an input N and returns the number at the Nth index
# position of the Lucas series.

def lucas_push(arr)
  arr.push(arr[-2]+arr[-1])
end

def lucas_unshift(arr)
  arr.unshift(arr[1]-arr[0])
end

def lucas_numbers(n)
  initial = [2,1]
  if n >= 0
    n.times {lucas_push(initial)}
    initial[n]
  elsif n < 0
    (-1*n).times {lucas_unshift(initial)}
    initial[0]
  end
end

# A palindrome is a word or sequence of words that reads the same backwards as
# forwards. Write a method that returns the longest palindrome in a given
# string. If there is no palindrome longer than two letters, return false.

def longest_palindrome(string)
  longest = ""
  arr = string.chars
  arr.each_with_index do |ch, i|
    if i == 0 or i == arr.length
    else
      testme = longest_odd_pal_given_start(string, i)
      longest = testme.join if longest.length < testme.length
      testme = longest_even_pal_given_start(string, i)
      longest = testme.join if longest.length < testme.length
    end
  end

  # confusion:
  # the contract above asks for the palindrome; the specs test for the palindrome length
  return longest.length if longest.length > 2
  return false
end

def longest_odd_pal_given_start(str,i)
  out = []
  out << str[i]
  j = 1
  while str[i+j] == str[i-j] && str[i+j] != nil && i-j > 0
    out.push(str.chars[i+j])
    out.unshift(str.chars[i-j])
    j += 1
  end
  out
end

def longest_even_pal_given_start(str,i)
  longest_odd_pal_given_start(str.chars.join(" "),2*i -1).reject { |x| x == ' ' }
end
