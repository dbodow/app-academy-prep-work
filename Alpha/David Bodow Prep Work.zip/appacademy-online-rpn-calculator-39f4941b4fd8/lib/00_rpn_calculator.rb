# The RPNCalculator evaluates computations given in reverse polish notation
class RPNCalculator
  # TODO: your code goes here!
  attr_reader :calculator

  # set up a dictionary of allowed operators
  def initialize
    @calculator = []
    @operators = { :+ => proc { plus },
                   :- => proc { minus },
                   :* => proc { times },
                   :/ => proc { divide } }
  end

  def push(token)
    @calculator.push(token)
  end

  def value
    @calculator.last
  end

  def plus
    raise 'calculator is empty' if calculator[-1].nil? || calculator[-2].nil?
    @calculator.push(@calculator.pop(2).inject(:+))
  end

  def minus
    raise 'calculator is empty' if calculator.nil? || calculator[-2].nil?
    @calculator.push(@calculator.pop(2).inject(:-))
  end

  def times
    raise 'calculator is empty' if calculator.nil? || calculator[-2].nil?
    @calculator.push(@calculator.pop(2).map(&:to_f).inject(:*))
  end

  def divide
    raise 'calculator is empty' if calculator.nil? || calculator[-2].nil?
    @calculator.push(@calculator.pop(2).map(&:to_f).inject(:/))
  end

  def tokens(str)
    out = []
    str.split(' ').each do |ch|
      if @operators.keys.map(&:to_s).include?(ch)
        out << ch.to_sym
      else
        out << ch.to_i
      end
    end
    out
  end

  def evaluate(str)
    tokens(str).each do |tok|
      if tok.is_a?(Symbol) # it's an operator
        @operators[tok].call
      else # it's a number
        calculator.push(tok)
      end
    end
    value
  end

end
