PATH = './lib/dictionary.txt'.freeze

# This class controls the game, passing turns back and forth between players
class Hangman
  attr_reader :guesser, :referee, :board

  def initialize(option_hash)
    @guesser = option_hash[:guesser]
    @referee = option_hash[:referee]
  end

  def setup
    @board = []
    @referee.pick_secret_word.times { @board << nil }
    @guesser.register_secret_length(@board.length)
  end

  def take_turn
    guess = @guesser.guess(@board)
    result = @referee.check_guess(guess)
    update_board(guess, result)
    @guesser.handle_response(guess, result)
  end

  def update_board(guess, result)
    result.each { |i| @board[i] = guess }
  end

  def play
    setup
    counter = 0
    loop do
      counter += 1
      take_turn
      puts "The word #{@board} was guessed." unless @board.include?(nil)
      puts "It took #{counter} guesses." unless @board.include?(nil)
      break unless @board.include?(nil)
      puts "The current board is #{@board}."
    end
  end
end

# This allows a human player to interact with the game
class HumanPlayer
  # why not just register a blank board of correct length?
  def initialize
    @past_guesses = []
  end

  def register_secret_length(length)
    @board = []
    length.times { @board << nil }
  end

  def guess(_board)
    puts 'Guess a letter in the word!'
    gets.chomp.downcase
  end

  # Why not just pass a board?
  def handle_response(guess, result)
    @past_guesses << guess
    result.each { |i| @board[i] = guess }
    puts "The board is now #{@board}."
    puts "So far, you've guessed #{@past_guesses}"
  end

  def pick_secret_word
    puts 'Think up a secret word. How long is it?'
    gets.chomp.to_i
  end

  def check_guess(char)
    gets
    puts "The opponent has guessed #{char}"
    out = []
    loop do
      puts 'Enter an index where the guess matches'
      puts '(If none remain, hit return)'
      index = gets.chomp
      return out if index.empty?
      out << index.to_i
    end
  end
end

# This allows a computer player to interact with the game
class ComputerPlayer
  attr_reader :candidate_words

  def self.parse_dictionary(path = PATH)
    out = []
    File.open(path).each_line { |l| out << l.chomp }
    out
  end

  def initialize(dictionary = ComputerPlayer.parse_dictionary)
    @dictionary = dictionary
    @past_guesses = []
    @candidate_words = []
    @dictionary.each { |x| @candidate_words << x } # deep copy
    @candidate_letters = Hash.new(0)
    ('a'.ord..'a'.ord + 25).each { |i| @candidate_letters[i.chr] = 0 }
  end

  def pick_secret_word
    @secret_word = @dictionary.sample.chars
    @secret_word.length
  end

  def check_guess(char)
    out = []
    @secret_word.each_with_index { |x, i| out << i if char == x }
    out
  end

  def register_secret_length(length)
    @board = []
    length.times { @board << nil }
    @candidate_words.select! { |x| x.length == length }
  end

  # computer guesses the most common letter in all words, but better would be
  # the letter than is in the most words
  def guess(board)
    # actually already done when filtering out the guess,
    # but this allows guessing from an arbitrary board to pass the specs.
    board.each { |ch| @candidate_letters.reject! { |x| x == ch } }
    # reset the count
    @candidate_letters.each_key { |k| @candidate_letters[k] = 0 }
    # find the most common candidate letter
    @candidate_words.each do |word|
      word.each_char do |ch|
        @candidate_letters[ch] += 1 if @candidate_letters.key?(ch)
      end
    end
    out = @candidate_letters.max_by { |_k, v| v }[0]
    # p "e"
    @candidate_letters.reject! { |x| x == out } # don't repeat guesses
    out
  end

  # why not just pass a board?
  def handle_response(guess, result)
    @past_guesses << guess
    result.each { |i| @board[i] = guess }
    # only look at candidate words with letters in the correct position
    result.each do |i|
      @candidate_words.select! { |w| w[i] == guess }
    end
    # reject candidate words with letters out of position
    @candidate_words.reject! do |w|
      testme = []
      w.each_char { |ch| testme << ch } # deep copy
      result.each { |i| testme[i] = nil if testme[i] == guess }
      if testme.include?(guess)
        true
      else
        false
      end
    end
    # reject candidate words with the given character if there was a miss
    @candidate_words.reject! { |w| w.include?(guess) } if result.empty?
  end
end
