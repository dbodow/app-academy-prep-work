class Fixnum

  # writes out 1 to 999
  def in_words_hundreds

    return '' if self.zero?

    ones_words = { 1 => 'one',
                   2 => 'two',
                   3 => 'three',
                   4 => 'four',
                   5 => 'five',
                   6 => 'six',
                   7 => 'seven',
                   8 => 'eight',
                   9 => 'nine' }

    tens_words = { 2 => 'twenty',
                   3 => 'thirty',
                   4 => 'forty',
                   5 => 'fifty',
                   6 => 'sixty',
                   7 => 'seventy',
                   8 => 'eighty',
                   9 => 'ninety' }

    teen_words = { 0 => 'ten',
                   1 => 'eleven',
                   2 => 'twelve',
                   3 => 'thirteen',
                   4 => 'fourteen',
                   5 => 'fifteen',
                   6 => 'sixteen',
                   7 => 'seventeen',
                   8 => 'eighteen',
                   9 => 'nineteen' }

    hund = (self / 100)
    tens = (self % 100) / 10
    ones = (self % 10)

    out = ''

    # write the hundreds
    out += ones_words[hund] + ' ' + 'hundred' unless hund.zero?

    # write the tens
    case tens
    when 1
      out += ' ' unless out.empty?
      return out += teen_words[ones]
    when (2..9)
      out += ' ' unless out.empty?
      out += tens_words[tens]
    end

    # write the ones
    out += ' ' unless out.empty? || ones.zero?
    out += ones_words[ones] unless ones.zero?
    out
  end

  def in_words

    return 'zero' if self.zero?

    cycle_names = { 0 => '',
                    1 => 'thousand',
                    2 => 'million',
                    3 => 'billion',
                    4 => 'trillion' }

    cycles = (self.to_s.length - 1) / 3

    out = ''
    (0..4).take(cycles + 1).reverse.each do |cyc|
      num_chunk = self % 10 ** ( 3*(cyc + 1) ) # trim off the top of the chunk
      num_chunk /= 10 ** ( 3*cyc ) # trim off the bottom of the chunk
      #p "num_chunk is #{num_chunk} and cyc is #{cyc}"
      out += ' ' unless out.empty? || num_chunk.zero?
      out += num_chunk.in_words_hundreds + ' ' + cycle_names[cyc] unless num_chunk.zero?
    end

    out += ' ' unless out[-1] == ' '
    out[0...-1] # trim the last whitespace

  end

end
