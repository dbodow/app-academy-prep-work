# I/O Exercises
#
# * Write a `guessing_game` method. The computer should choose a number between
#   1 and 100. Prompt the user to `guess a number`. Each time through a play loop,
#   get a guess from the user. Print the number guessed and whether it was `too
#   high` or `too low`. Track the number of guesses the player takes. When the
#   player guesses the number, print out what the number was and how many guesses
#   the player needed.
# * Write a program that prompts the user for a file name, reads that file,
#   shuffles the lines, and saves it to the file "{input_name}-shuffled.txt". You
#   could create a random number using the Random class, or you could use the
#   `shuffle` method in array.

def guessing_game
  secret_number = Random.rand(100) + 1
  num_guesses = 0
  while true
    puts 'Guess a number'
    my_guess = gets.chomp.to_i
    puts my_guess
    num_guesses += 1
    case my_guess <=> secret_number
    when -1 #(1...secret_number) # too small
      puts "Guessed #{my_guess}: was too low!"
    when 0 # matches!
      puts "Guessed #{my_guess}: was the match!"
      puts "It took #{num_guesses} tries."
      break
    when 1 # too high
      puts "Guessed #{my_guess}: was too high!"
    end
  end
end

# Write file_shuffler program that: * prompts the user for a file name * reads
# that file * shuffles the lines * saves it to the file "{input_name}-shuffled.txt".

def file_shuffler
  puts "Please enter a file path"
  file_name = gets.chomp
  to_write = File.readlines(file_name).shuffle
  File.open(file_name + "-shuffled.txt", "w") do |f|
    to_write.each { |line| f.puts line }
  end
end
