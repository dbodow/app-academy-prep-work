# EASY

# Define a method that, given a sentence, returns a hash of each of the words as
# keys with their lengths as values. Assume the argument lacks punctuation.
def word_lengths(str)
  out = Hash.new(0)
  str.split(' ').each { |word| out[word] = word.length }
  out
end

# Define a method that, given a hash with integers as values, returns the key
# with the largest value.
def greatest_key_by_val(hash)
  # more code, but linear time when compared to sorting the hash and returning the biggest one
  return nil if hash == {} # data validation
  biggest = -1.0 / 0.0 # guaranteed to be overwritten by assumption that we have a non-empty hash of integers
  hash.each_value { |val| biggest = val if biggest < val }
  hash.select { |key, val| val == biggest }.keys[0]
  # values aren't necessarily unique; without further instruction, I'll return the first key with the biggest value
end

# Define a method that accepts two hashes as arguments: an older inventory and a
# newer one. The method should update keys in the older inventory with values
# from the newer one as well as add new key-value pairs to the older inventory.
# The method should return the older inventory as a result. march = {rubies: 10,
# emeralds: 14, diamonds: 2} april = {emeralds: 27, moonstones: 5}
# update_inventory(march, april) => {rubies: 10, emeralds: 27, diamonds: 2,
# moonstones: 5}
def update_inventory(older, newer)
  newer.each { |key, val| older[key] = val }
  older
end

# Define a method that, given a word, returns a hash with the letters in the
# word as keys and the frequencies of the letters as values.
def letter_counts(word)
  out = Hash.new(0)
  word.chars.each { |ch| out[ch] += 1 }
  out
end

# MEDIUM

# Define a method that, given an array, returns that array without duplicates.
# Use a hash! Don't use the uniq method.
def my_uniq(arr)
  out = {}
  arr.each { |item| out[item] = nil }
  out.keys
end

# Define a method that, given an array of numbers, returns a hash with "even"
# and "odd" as keys and the frequency of each parity as values.

# Note to the grader: you ask for string keys in your description here,
# but the spec file tests for symbol keys
def evens_and_odds(numbers)
  out = { even: 0, odd: 0 } # base case
  numbers.each do |num|
    if num % 2 == 0
      out[:even] += 1
    elsif num % 2 == 1 # we can't assume the nums are integers with this contract
      out[:odd] += 1
    end
  end
  out
end

# Define a method that, given a string, returns the most common vowel. If
# there's a tie, return the vowel that occurs earlier in the alphabet. Assume
# all letters are lower case.
def most_common_vowel(string)
  vowel_count = { 'a' => 0, 'e' => 0, 'i' => 0, 'o' => 0, 'u' => 0 }
  string.chars.each { |ch| vowel_count[ch] += 1 }
  vowel_count = vowel_count.sort_by { |key, val| val }
  vowel_count.select { |key, val| val == vowel_count[-1][-1]}.first.first
end

# HARD

# Define a method that, given a hash with keys as student names and values as
# their birthday months (numerically, e.g., 1 corresponds to January), returns
# every combination of students whose birthdays fall in the second half of the
# year (months 7-12). students_with_birthdays = { "Asher" => 6, "Bertie" => 11,
# "Dottie" => 8, "Warren" => 9 }
# fall_and_winter_birthdays(students_with_birthdays) => [ ["Bertie", "Dottie"],
# ["Bertie", "Warren"], ["Dottie", "Warren"] ]

# DB: This contract is poorly defined; based on the example, it seems that
# "combination" means "unique pair" though the spec file seems to expect the
# pairs to arrive in a certain order even though the specification for that
# order is not given. I'll do my best with this

def fall_and_winter_birthdays(students)
  students = students.select! { |k, v| v >= 7 }.keys
  out = []
  students.each_with_index do |stu, i|
    partners = students[i+1..-1]
    return out if partners.nil?
    partners.each { |partner| out << [stu, partner] }
  end
  out
end

# Define a method that, given an array of specimens, returns the biodiversity
# index as defined by the following formula: number_of_species**2 *
# smallest_population_size / largest_population_size biodiversity_index(["cat",
# "cat", "cat"]) => 1 biodiversity_index(["cat", "leopard-spotted ferret",
# "dog"]) => 9
def biodiversity_index(specimens)
  population = Hash.new(0)
  specimens.each { |anim| population[anim] += 1 }
  num_species = population.keys.length
  largest_pop = population.values.sort[-1]
  smallest_pop = population.values.sort[0]
  num_species**2 * smallest_pop / largest_pop
end

# Define a method that, given the string of a respectable business sign, returns
# a boolean indicating whether pranksters can make a given vandalized string
# using the available letters. Ignore capitalization and punctuation.
# can_tweak_sign("We're having a yellow ferret sale for a good cause over at the
# pet shop!", "Leopard ferrets forever yo") => true
def can_tweak_sign?(normal_sign, vandalized_sign)
  # ignore capitalization
  normal_sign.downcase!
  vandalized_sign.downcase!

  # trim punctuation and spacing
  punctuation = %w[! - ; : , . " '] + [' ', '\n'] # adapt as needed
  normal_sign = normal_sign.chars.reject do |ch|
    punctuation.any? { |pun| pun == ch }
  end .join
  vandalized_sign = vandalized_sign.chars.reject do |ch|
    punctuation.any? { |pun| pun == ch }
  end .join

  # process answer
  normal_chars = character_count(normal_sign)
  vandal_chars = character_count(vandalized_sign)
  vandal_chars.each do |key, val|
    normal_chars[key] -= val
  end
  normal_chars.values.all? { |item| item >= 0 }
end

def character_count(str)
  out = Hash.new(0)
  str.chars.each { |ch| out[ch] += 1 }
  out
end
