def ftoc(farenheit)
  (farenheit - 32) * 5 / 9.0
end

def ctof (celsius)
  (celsius * 9 / 5.0) + 32
end
