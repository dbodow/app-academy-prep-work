def echo(str)
  str
end

def shout(str)
  str.upcase
end

def repeat(str, number=2)
  ( (str + " ") * number )[0..-2]
end

def start_of_word(str, number)
  str[0...number]
end

def first_word(str)
  str.split(" ")[0]
end

# The test specs ask to do this in a more refined way than just looking at
# the word length. E.g. in "The Bridge over the River Kwai", "over" is lowercase
# while "Kwai" is capitalized.

# My solution is to create a dictionary of banned words based on their most
# common part of speech. This solution will exclude common prepositions and
# coordinating conjunctions. It will be clear how it can be extended by
# adding new words to banned dictionaries or banned classes of words by adding
# new dictionaries.

# However, my guess is that this is an oversight from the problem designer and
# that the intended solution is to filter out words by length and capitalize them
# I recommend clarifying instructions for this problem for the next cycle.

# exclusion rules:
# http://grammar.yourdictionary.com/capitalization/rules-for-capitalization-in-titles.html

# PS: Ideally, I'd like to keep these dictionaries in a separate datafile,
# but we haven't covered how to separate out code and data yet.

def titleize(words)
  coordinating_conjunctions = %w[for and nor but or yet so] #FANBOYS
  # list: https://www.englishclub.com/vocabulary/common-prepositions-25.htm
  prepositions = %w[of in to for with on at from by about as into like through after over between out against during without before under around among]
  articles = %w[a an the]
  out = words.split(" ").each do |word|
    word.capitalize! unless (coordinating_conjunctions + prepositions + articles).include?(word)
  end
  out[0].capitalize!
  out.join(" ")
end
