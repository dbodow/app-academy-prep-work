VOWELS = %w(a e i o u)
PUNCTUATION = %w(. , ! ? : ;)

def translate_one(word)
  # preprocess: convert to array and lump chars into qu phonemes
  processme = word.chars
  processme.each_with_index do |ch, i|
    if ch == "q" && processme[i+1] == "u"
      processme[i] = "qu"
      processme[i+1] = ""
      processme.reject!{|ch| ch == ""}
    end
  end

  # translate
  i = 0
  until VOWELS.include?(processme[i]) || i > processme.length
    i += 1
  end
  processme = (processme[i..-1] + processme[0...i] + ['a','y'])

  # punctuate (assumed to always get put at the end)
  append = processme.select { |ch| PUNCTUATION.include?(ch) }
  processme = processme.reject { |ch| PUNCTUATION.include?(ch) } + append

  # join
  processme = processme.join

  # capitalize
  processme.capitalize! if word[0].upcase == word[0]

  # output
  processme
end

def translate(words)
  words.split(" ").map { |word| translate_one(word) }.join(" ")
end
