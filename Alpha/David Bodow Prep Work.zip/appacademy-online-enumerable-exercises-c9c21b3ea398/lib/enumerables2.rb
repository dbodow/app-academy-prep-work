require 'byebug'

# EASY

# Define a method that returns the sum of all the elements in its argument (an
# array of numbers).
def array_sum(arr)
  arr.reduce(0,:+)
end

# Define a method that returns a boolean indicating whether substring is a
# substring of each string in the long_strings array.
# Hint: you may want a sub_tring? helper method
def in_all_strings?(long_strings, substring)
  long_strings.reduce(true){|accum, item| accum && substring?(item, substring)}
end

def substring?(original_str, test_str)
  original_str.chars.each_cons(test_str.length) do |item|
    return true if item == test_str.chars
  end
  false
end

# true iff test_str is a substring of original_str without rotations
# def perfect_substring?(original_str, test_str)
#   return true if original_str.chars.zip(test_str.chars).map{ |x| x[0].equal?(x[1])}.count(true) == test_str.length
#   false
# end

# Define a method that accepts a string of lower case words (no punctuation) and
# returns an array of letters that occur more than once, sorted alphabetically.
def non_unique_letters(string)
  duplicates = []
  str_arr = string.chars
  str_arr.each do |ch|
    duplicates << ch if str_arr.count(ch) > 1
  end
  duplicates.uniq.sort.reject{|x| x == ' '} # Spaces are invalid characters for this
end

# Define a method that returns an array of the longest two words (in order) in
# the method's argument. Ignore punctuation!

def remove_punctuation(string)
  # The problem gives a very poor definition of "punctuation"
  # Just add any other excluded symbols below
  str_arr = string.chars
  punctuation = %W(! - , . ? ' : ;)
  punctuation.each {|ch| str_arr.reject!{|x| x == ch}}
  str_arr.join
end

def longest_two_words(string)
  remove_punctuation(string).split(" ").sort_by{ |word| word.length }.reverse[0,2]
end

# MEDIUM

# Define a method that takes a string of lower-case letters and returns an array
# of all the letters that do not occur in the method's argument.
def missing_letters(string)
  lowers = %w(a b c d e f g h i j k l m n o p q r s t u v w x y z)
  string.chars.each{|ch| lowers.reject!{|x| x == ch}}
  lowers
end

# Define a method that accepts two years and returns an array of the years
# within that range (inclusive) that have no repeated digits. Hint: helper
# method?
def no_repeat_years(first_yr, last_yr)
  (first_yr..last_yr).select{|year| not_repeat_year?(year)}
end

def not_repeat_year?(year)
  return true if year.to_s.chars.uniq == year.to_s.chars
  false
end

# HARD

# Define a method that, given an array of songs at the top of the charts,
# returns the songs that only stayed on the chart for a week at a time. Each
# element corresponds to a song at the top of the charts for one particular)
# week. Songs CAN reappear on the chart, but if they don't appear in consecutive
# weeks, they're "one-week wonders." Suggested strategy: find the songs that
# appear multiple times in a row and remove them. You may wish to write a helper
# method no_repeats?
def one_week_wonders(songs)
  repeats(songs).each { |repeated| songs.reject!{|song| repeated == song}}
  songs.uniq
end

def repeats(songs)
  out = []
  songs.each_cons(2) { |pair| out << pair[0] if pair[0] == pair[1] }
  out.uniq
end

# Define a method that, given a string of words, returns the word that has the
# letter "c" closest to the end of it. If there's a tie, return the earlier
# word. Ignore punctuation. If there's no "c", return an empty string. You may
# wish to write the helper methods c_distance and remove_punctuation.

def for_cs_sake(string)
  remove_punctuation(string).split(" ").reduce("") do |accum, current|
    if c_distance(current) < c_distance(accum)
      current
    else
      accum
    end
  end
end

# distance to end if c is present; nil if c is not present
def c_distance(word)
  out = remove_punctuation(word).reverse.chars.index("c")
  out = 1.0/0.0 if out == nil
  out
end

# Define a method that, given an array of numbers, returns a nested array of
# two-element arrays that each contain the start and end indices of whenever a
# number appears multiple times in a row. repeated_number_ranges([1, 1, 2]) =>
# [[0, 1]] repeated_number_ranges([1, 2, 3, 3, 4, 4, 4]) => [[2, 3], [4, 6]]

def repeated_number_ranges(arr)
  out = repeated_arr_maker(arr).join.split(" ").map(&:chars).map {|x| trim_array(x)}
  out.map!{ |inner_arr| inner_arr.map{ |n| n.to_i}}
end

# first get an intermediate array: string number of the index if part of a sequence; " " otherwise
# then we can save work in partitioning the array using split(" ")!
def repeated_arr_maker(arr)
  return [] if arr == []
  return arr if arr.length == 1
  repeats = []
  arr.each_with_index do |num, index|
    if num == arr[index + 1] or num == arr[index - 1]
      repeats << index.to_s
      repeats << " " if num != arr[index + 1] # this adds separations for partitioning later
    else
      repeats << " "
    end
  end
  repeats[0] = " " if arr[0] != arr[1] # deals with wrapping problem
  repeats
end

# give an array of only the first and last values in an array
def trim_array(arr)
  [arr[0], arr[-1]]
end
