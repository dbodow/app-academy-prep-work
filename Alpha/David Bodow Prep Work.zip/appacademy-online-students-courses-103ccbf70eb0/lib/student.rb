# ## Student
# * `Student#initialize` should take a first and last name.
# * `Student#name` should return the concatenation of the student's
#   first and last name.
# * `Student#courses` should return a list of the `Course`s in which
#   the student is enrolled.
# * `Student#enroll` should take a `Course` object, add it to the
#   student's list of courses, and update the `Course`'s list of
#   enrolled students.
#     * `enroll` should ignore attempts to re-enroll a student.
# * `Student#course_load` should return a hash of departments to # of
#   credits the student is taking in that department.

class Student

  attr_reader :first_name, :last_name
  attr_accessor :courses # double check I still need writable this at end

  def initialize(first_name, last_name)
    @first_name = first_name
    @last_name = last_name
    @courses = []
  end

  def name
    @first_name + ' ' + @last_name
  end

  def enroll(course)
    # ignore re-enrolls
    unless @courses.include?(course)

      # check for enrollment clashes
      courses.each do |c|
        raise "class conflict!" if c.conflicts_with?(course)
      end
      #
      # update both the student and the course
      @courses << course
      #course.students += [self] #this version seemed to work but failed the specs
      # investigate further!
      course.students << self

      # course.add_student(self)
      # @courses << course
    end
    nil
  end

  def course_load
    out = Hash.new(0)
    courses.each { |c| out[c.department] += c.credits }
    out
  end

end
