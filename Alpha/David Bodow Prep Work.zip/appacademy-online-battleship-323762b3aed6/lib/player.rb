class HumanPlayer
  def get_play
    out = []
    puts 'What row would you like to attack?'
    out << gets.chomp
    puts 'What column would you like to attack?'
    out << gets.chomp
    puts 'Attacking!'
    out
  end
end
