class Board
  attr_accessor :grid

  def self.default_grid
    out = []
    10.times { out << Array.new(10, 0) } # 0 represents empty, 1 is ship
    out
  end

  def initialize(grid = Board.default_grid)
    @grid = grid
  end

  # convention: `nil' means `no ship'; `:s' means `ship'; `x' means `fired upon'
  # Specs only work for (1x1) ships: this calculates the number of used squares
  # not the number of ships (which is not fully determined by game state)
  # for instance, the following game state could be 2 (3x1) ships of 3 (2x1)s
  # -SS
  # -SS
  # -SS
  def count
    @grid.flatten.count(:s)
  end

  def empty?(arr = nil)
    case arr
    when nil
      return true if count.zero?
      false
    when Array
      return false if grid[arr[0]][arr[1]] == :s
      true
    end
  end

  def full?
    @grid.each do |arr|
      return false if arr.include?(nil)
    end
    true
  end

  def available_spots
    out = []
    @grid.each_with_index do |arr, rowi|
      arr.each_with_index { |entry, coli| out << [rowi, coli] if entry.nil? }
    end
    out
  end

  def place_random_ship
    raise 'full board, cannot add more' if full?
    new_pos = available_spots.sample
    @grid[new_pos[0]][new_pos[1]] = :s
  end

  def won?
    return true if empty?
    false
  end

  def [](arr)
    @grid[arr[0]][arr[1]]
  end
end
