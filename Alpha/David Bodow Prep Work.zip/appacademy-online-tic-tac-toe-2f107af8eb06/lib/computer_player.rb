class ComputerPlayer
  attr_reader :name, :board
  attr_accessor :mark

  def initialize(name)
    @name = name
  end

  def display(board)
    @board = board
  end

  def get_move
    # Find all available moves
    available = []
    @board.grid.each_with_index do |row, i|
      row.each_with_index { |entry, j| available << [i, j] if entry.nil? }
    end

    # test if any of the available moves give a win
    available.each do |move|
      @board.place_mark(move, @mark)
      wins = true if @board.winner == @mark
      @board.place_mark(move, nil) # clean-up!
      return move if wins
    end

    # as default, give a random move
    available.sample
  end
end
