class Board
  attr_reader :grid

  def initialize(grid = Array.new(3) { Array.new(3) })
    @grid = grid
  end

  def place_mark(pos, mark)
    @grid[pos[0]][pos[1]] = mark
  end

  def empty?(pos)
    if @grid[pos[0]][pos[1]].nil?
      true
    else
      false
    end
  end

  def winner
    # check for row wins
    @grid.each do |row|
      return row[0] if row.all? { |entry| entry == row[0] } && !row[0].nil?
    end

    # check for column wins
    @grid.transpose.each do |col|
      return col[0] if col.all? { |entry| entry == col[0] } && !col[0].nil?
    end

    # check for falling diagonal wins
    diagonal = []
    (0...@grid.length).each { |i| diagonal << @grid[i][i] }
    return diagonal[0] if diagonal.all? { |entry| entry == diagonal[0] } && !diagonal[0].nil?

    # check for rising diagonal wins
    diagonal = []
    (0...@grid.length).each { |i| diagonal << @grid[i][@grid.length - i - 1] }
    return diagonal[0] if diagonal.all? { |entry| entry == diagonal[0] } && !diagonal[0].nil?
    nil
  end

  def over?
    if @grid.flatten.include?(nil) & !winner
      false
    else
      true
    end
  end
end
