class Code
  attr_reader :pegs

  # Why do the specs call for a hash here???
  PEGS = { 'r' => true,
           'g' => true,
           'b' => true,
           'y' => true,
           'o' => true,
           'p' => true }

  def self.parse(string)
    out = []
    string.downcase.each_char do |c|
      raise "invalid color: #{c}." unless PEGS[c]
      out << c
    end
    Code.new(out)
  end

  def self.random
    out = []
    4.times { out << PEGS.keys.sample }
    Code.new(out)
  end

  def initialize(arr)
    @pegs = arr
  end

  def [](i)
    @pegs[i]
  end

  def exact_matches(code)
    matches = 0
    code.pegs.each_with_index do |c, i|
      matches += 1 if c == self[i]
    end
    matches
  end

  def near_matches(code)
    counter = Hash.new(0)
    pegs.each { |c| counter[c] += 1 }
    counter.default = false
    code.pegs.each do |c|
      counter[c] -= 1 if counter[c] && counter[c] > 0
    end
    4 - counter.values.reduce(&:+) - exact_matches(code)
  end

  def ==(code)
    return false if code.class != Code
    return false if pegs != code.pegs
    true
  end
end

class Game
  attr_reader :secret_code

  def initialize(code = Code.random)
    @secret_code = code
  end

  def get_guess
    puts 'Please guess the code.'
    begin
      Code.parse(gets.chomp)
    rescue
      puts 'Try a code with allowed colors'
      retry
    end
  end

  def display_matches(code)
    exact = secret_code.exact_matches(code)
    near = secret_code.near_matches(code)
    puts "There are #{exact} exact matches and #{near} near matches."
  end
end
