# EASY

# Return the argument with all its lowercase characters removed.
def destructive_uppercase(str)
  out_string = ''
  (0..str.length - 1).each do |index|
    out_string += str[index] if str[index] == str[index].upcase
  end
  out_string
end

# Return the middle character of a string. Return the middle two characters if
# the word is of even length, e.g. middle_substring("middle") => "dd",
# middle_substring("mid") => "i"
def middle_substring(str)
  telomere_length = (str.length - 1) / 2
  telomere_length.times { str.chop! }
  str.reverse!
  telomere_length.times { str.chop! }
  str.reverse!
end

# Return the number of vowels in a string.
VOWELS = %w(a e i o u)
def num_vowels(str)
  vowel_list = VOWELS + VOWELS.map{ |vowel| vowel.upcase }
  consonants = str.delete(vowel_list.join)
  str.length - consonants.length
end

# Return the factoral of the argument (num). A number's factorial is the product
# of all whole numbers between 1 and the number itself. Assume the argument will
# be > 0.
def factorial(num)
  product = 1
  (1..num).each { |item| product *= item }
  product
end


# MEDIUM

# Write your own version of the join method. separator = "" ensures that the
# default seperator is an empty string.
def my_join(arr, separator = "")
  out_string = ''
  if arr.length.zero?
    out_string
  else
    out_string = arr.first # Set up the first element, which has no separator
    return out_string if arr.length == 1
    arr[1..-1].each { |item| out_string += separator + item.to_s }
    out_string
  end
end

# Write a method that converts its argument to weirdcase, where every odd
# character is lowercase and every even is uppercase, e.g.
# weirdcase("weirdcase") => "wEiRdCaSe"
def weirdcase(str)
  out_string = ''
  (0...str.length).each do |index|
    if index.odd?
      out_string += str[index].upcase
    else
      out_string += str[index].downcase
    end
  end
  out_string
end

# Reverse all words of five more more letters in a string. Return the resulting
# string, e.g., reverse_five("Looks like my luck has reversed") => "skooL like
# my luck has desrever")
def reverse_five(str)
  out_arr = []
  str.split(' ').each do |word|
    if word.length < 5
      out_arr << word
    else
      out_arr << word.reverse
    end
  end
  out_arr.join(' ')
end

# Return an array of integers from 1 to n (inclusive), except for each multiple
# of 3 replace the integer with "fizz", for each multiple of 5 replace the
# integer with "buzz", and for each multiple of both 3 and 5, replace the
# integer with "fizzbuzz".char
def fizzbuzz(n)
  out_arr = []
  (1..n).each do |int|
    mult_three = (int % 3).zero?
    mult_five = (int % 5).zero?
    if mult_three && mult_five
      out_arr << "fizzbuzz"
    elsif mult_three
      out_arr << "fizz"
    elsif mult_five
      out_arr << "buzz"
    else
      out_arr << int
    end
  end
  out_arr
end


# HARD

# Write a method that returns a new array containing all the elements of the
# original array in reverse order.
def my_reverse(arr)
  out_arr = []
  arr.each { |item| out_arr.unshift(item) }
  out_arr
end

# Write a method that returns a boolean indicating whether the argument is
# prime.
# Note to self: come back and try to improve performance if time allows later
# This includes many unnecessary operations
def prime?(num)
  return false if num == 1 # Base case
  possible_factors = (2..(num**0.5).floor).to_a # The sqrt of an integer is an upper bound for its prime factors
  possible_factors.each do |test_factor|
    return false if (num % test_factor).zero?
  end
  true
end

# Write a method that returns a sorted array of the factors of its argument.
# Note to self: add number-theoretic optimizations later if time
def factors(num)
  out_arr = []
  (1..num).each { |item| out_arr << item if (num % item).zero? }
  out_arr
end

# Write a method that returns a sorted array of the prime factors of its argument.
def prime_factors(num)
  out_arr = []
  factors(num).each { |item| out_arr << item if prime?(item) }
  out_arr
end

# Write a method that returns the number of prime factors of its argument.
def num_prime_factors(num)
  prime_factors(num).length
end


# EXPERT

# Return the one integer in an array that is even or odd while the rest are of
# opposite parity, e.g. oddball([1,2,3]) => 2, oddball([2,4,5,6] => 5)
def oddball(arr)
  # ASSUMPTION: arrays are of length 3 or more
  # The current definition would have two valid outputs for e.g. [1,2]
  # TRICK: We can count the number of odds and evens by noting that:
  # item % 2 -> 0 iff item is even and item % 2 -> 1 iff item is odd
  # Then, just use a fold to add up how many ones (Ruby calls folding "reduce")
  parity_arr = arr.map { |item| item % 2 }
  odds = parity_arr.reduce(:+)
  evens = arr.length - odds
  # Validate data
  if (odds != 1) && (evens != 1)
    puts 'There is no lone odd or even'
  elsif odds == 1
    arr[parity_arr.index(1)]
  else
    arr[parity_arr.index(0)]
  end
end
