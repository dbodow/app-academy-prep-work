def reverser
  yield.split.map!{|word| word.reverse}.join(" ")
end

def adder(extra=1)
  yield + extra
end

def repeater(num=1)
  num.times{yield}
end
