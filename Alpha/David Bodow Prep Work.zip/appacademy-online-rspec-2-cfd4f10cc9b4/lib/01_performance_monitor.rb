def measure(repeats = 1)
  start = Time.now
  repeats.times { yield }
  stop = Time.now
  (stop - start) / repeats.to_f
end
